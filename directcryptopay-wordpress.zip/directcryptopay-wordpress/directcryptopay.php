<?php
/**
 * Plugin Name: DirectCryptoPay
 * Plugin URI:  https://directcryptopay.com
 * Description: Accept crypto payments and donations directly on your WordPress site. Includes WooCommerce gateway. Web3, Non-custodial, No middlemen.
 * Version:     1.5.1
 * Author:      DirectCryptoPay
 * Author URI:  https://directcryptopay.com
 * License:     GPLv2 or later
 * Text Domain: directcryptopay
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('DCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DCP_VERSION', '1.5.1');

/**
 * Add Settings Menu
 */
add_action('admin_menu', 'dcp_create_menu');

function dcp_create_menu() {
    add_menu_page(
        'DirectCryptoPay Settings',
        'DirectCryptoPay',
        'manage_options',
        'dcp-settings',
        'dcp_settings_page',
        'dashicons-money-alt',
        100
    );
    add_action('admin_init', 'dcp_register_settings');
}

function dcp_register_settings() {
    register_setting('dcp-settings-group', 'dcp_public_id');
    register_setting('dcp-settings-group', 'dcp_webhook_secret');
}

function dcp_settings_page() {
    $public_id = get_option('dcp_public_id', '');
    $webhook_secret = get_option('dcp_webhook_secret', '');
    $webhook_url = add_query_arg('wc-api', 'wc_gateway_directcryptopay', home_url('/'));
    $is_configured = !empty($public_id);
    ?>
    <div class="wrap">
        <h1>💎 DirectCryptoPay - Setup</h1>

        <?php if (!$is_configured): ?>
        <!-- Setup Wizard -->
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 8px; margin: 20px 0;">
            <h2 style="color: white; margin-top: 0;">🚀 Welcome! Setup in 4 Steps</h2>
            <p style="font-size: 16px; opacity: 0.95;">Follow this guide to accept crypto payments on your WordPress site</p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin: 30px 0;">
            <!-- Step 1: Create Account -->
            <div style="background: white; border: 2px solid #e5e7eb; border-radius: 8px; padding: 25px;">
                <div style="background: #f59e0b; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px; margin-bottom: 15px;">1</div>
                <h3 style="margin-top: 0; color: #1f2937;">Create Account</h3>
                <p style="color: #6b7280; margin-bottom: 20px;">Don't have an account? Sign up for free on DirectCryptoPay.</p>
                <a href="https://directcryptopay.com/auth/signin" target="_blank" style="display: inline-block; background: #f59e0b; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 15px;">
                    ✨ Sign Up / Login →
                </a>
            </div>

            <!-- Step 2: Create Integration -->
            <div style="background: white; border: 2px solid #e5e7eb; border-radius: 8px; padding: 25px;">
                <div style="background: #3b82f6; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px; margin-bottom: 15px;">2</div>
                <h3 style="margin-top: 0; color: #1f2937;">Create Integration</h3>
                <p style="color: #6b7280; margin-bottom: 20px;">In your Dashboard, go to Integrations and create a new integration.</p>
                <a href="https://directcryptopay.com/dashboard/integrations" target="_blank" style="display: inline-block; background: #3b82f6; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 500;">
                    📊 Open Dashboard →
                </a>
            </div>

            <!-- Step 3: Copy Integration ID -->
            <div style="background: white; border: 2px solid #e5e7eb; border-radius: 8px; padding: 25px;">
                <div style="background: #10b981; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px; margin-bottom: 15px;">3</div>
                <h3 style="margin-top: 0; color: #1f2937;">Copy Integration ID</h3>
                <p style="color: #6b7280; margin-bottom: 20px;">In the Integrations list, copy the <strong>Integration ID</strong> (column "Integration ID").</p>
                <div style="background: #f3f4f6; padding: 15px; border-radius: 6px; border-left: 4px solid #10b981;">
                    <code style="font-size: 13px; color: #374151;">Example: int_sub_01ka9z...</code>
                </div>
            </div>

            <!-- Step 4: Configure WordPress -->
            <div style="background: white; border: 2px solid #e5e7eb; border-radius: 8px; padding: 25px;">
                <div style="background: #8b5cf6; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px; margin-bottom: 15px;">4</div>
                <h3 style="margin-top: 0; color: #1f2937;">Configure Plugin</h3>
                <p style="color: #6b7280; margin-bottom: 20px;">Paste your Integration ID in the form below and save.</p>
                <div style="background: #f3f4f6; padding: 15px; border-radius: 6px;">
                    <p style="margin: 0; font-size: 14px; color: #6b7280;">👇 See form below</p>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- Configuration Success -->
        <div style="background: #d1fae5; border: 2px solid #10b981; border-radius: 8px; padding: 20px; margin: 20px 0;">
            <h3 style="color: #065f46; margin-top: 0;">✅ Plugin Configured!</h3>
            <p style="color: #047857; margin-bottom: 0;">Your Integration ID is saved. You can now use shortcodes on your pages.</p>
        </div>
        <?php endif; ?>

        <!-- Configuration Form -->
        <form method="post" action="options.php" style="background: white; padding: 25px; border: 1px solid #e5e7eb; border-radius: 8px; margin-top: 30px;">
            <?php settings_fields('dcp-settings-group'); ?>
            <?php do_settings_sections('dcp-settings-group'); ?>

            <h2 style="margin-top: 0;">⚙️ Configuration</h2>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">
                        <label for="dcp_public_id">Integration ID <span style="color: #dc2626;">*</span></label>
                    </th>
                    <td>
                        <input
                            type="text"
                            id="dcp_public_id"
                            name="dcp_public_id"
                            value="<?php echo esc_attr($public_id); ?>"
                            class="regular-text"
                            placeholder="int_sub_01ka9zhg4e3cb3..."
                            required
                            style="font-family: monospace; font-size: 14px;"
                        />
                        <p class="description">
                            <strong>How to get your Integration ID:</strong><br>
                            1. Go to your <a href="https://directcryptopay.com/dashboard/integrations" target="_blank" style="color: #3b82f6; text-decoration: none; font-weight: 500;">DirectCryptoPay Dashboard → Integrations</a><br>
                            2. Find the integration you want to use<br>
                            3. Copy the <strong>Integration ID</strong> from the "Integration ID" column (starts with <code>int_</code>)<br>
                            4. Paste it in the field above<br>
                            <span style="color: #dc2626;">⚠️ Important:</span> Use the <strong>Integration ID</strong>, not the integration name.
                        </p>
                    </td>
                </tr>
            </table>

            <h2 style="margin-top: 30px;">🔗 Webhook Configuration <span style="font-size: 13px; font-weight: normal; color: #6b7280;">(Optional)</span></h2>
            <p style="color: #6b7280; margin-bottom: 15px;">Webhooks allow your WordPress site to receive real-time payment notifications from DirectCryptoPay.</p>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">
                        <label>Webhook URL</label>
                    </th>
                    <td>
                        <code style="display: inline-block; background: #f3f4f6; padding: 8px 14px; border-radius: 6px; font-size: 13px; border: 1px solid #e5e7eb; user-select: all;"><?php echo esc_html($webhook_url); ?></code>
                        <p class="description">
                            Copy this URL and paste it in your <a href="https://directcryptopay.com/dashboard/integrations" target="_blank" style="color: #3b82f6; text-decoration: none; font-weight: 500;">DCP Dashboard → Integrations → Webhook URL</a>.
                        </p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">
                        <label for="dcp_webhook_secret">Webhook Secret</label>
                    </th>
                    <td>
                        <input
                            type="password"
                            id="dcp_webhook_secret"
                            name="dcp_webhook_secret"
                            value="<?php echo esc_attr($webhook_secret); ?>"
                            class="regular-text"
                            placeholder="whsec_..."
                            autocomplete="off"
                            style="font-family: monospace; font-size: 14px;"
                        />
                        <button type="button" class="button" onclick="var f=document.getElementById('dcp_webhook_secret');f.type=(f.type==='password'?'text':'password');">👁 Reveal</button>
                        <p class="description">
                            Copy the <strong>Webhook Secret</strong> from your DCP Dashboard → Integrations → click your integration → Webhook Secret (starts with <code>whsec_</code>).<br>
                            Used to verify that incoming webhooks are genuinely from DirectCryptoPay.
                        </p>
                    </td>
                </tr>
            </table>

            <?php submit_button('💾 Save Configuration'); ?>
        </form>

        <!-- Usage Guide -->
        <div style="background: white; padding: 25px; border: 1px solid #e5e7eb; border-radius: 8px; margin-top: 30px;">
            <h2 style="margin-top: 0;">📖 How to Use</h2>

            <div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin: 20px 0;">
                <h3 style="color: #1e40af; margin-top: 0;">Method 1: Shortcode (Quick & Easy)</h3>
                <p style="color: #1e40af;">Add this code to any page, post, or widget:</p>
                <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 6px; overflow-x: auto; margin: 15px 0;"><code>[dcp_pay amount="10" label="Pay with Crypto"]</code></pre>

                <h4 style="color: #1e40af; margin-top: 20px;">Available Parameters:</h4>
                <ul style="color: #1e40af; line-height: 1.8;">
                    <li><code style="background: #dbeafe; padding: 2px 8px; border-radius: 4px;">amount</code> - Amount in USD (ex: <code>amount="10"</code>)</li>
                    <li><code style="background: #dbeafe; padding: 2px 8px; border-radius: 4px;">label</code> - Button text (ex: <code>label="Donate Now"</code>)</li>
                    <li><code style="background: #dbeafe; padding: 2px 8px; border-radius: 4px;">currency</code> - Crypto token to accept (default: ETH, supported: ETH, USDC, USDT)</li>
                    <li><code style="background: #dbeafe; padding: 2px 8px; border-radius: 4px;">success_url</code> - <strong>NEW!</strong> Custom page after successful payment (ex: <code>success_url="https://example.com/thank-you"</code>)</li>
                    <li><code style="background: #dbeafe; padding: 2px 8px; border-radius: 4px;">error_url</code> - <strong>NEW!</strong> Custom page if payment fails (ex: <code>error_url="https://example.com/error"</code>)</li>
                </ul>

                <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 15px 0; border-radius: 4px;">
                    <strong style="color: #92400e;">💡 Tip:</strong>
                    <span style="color: #92400e;"> You can customize the token for each button:</span>
                    <ul style="color: #92400e; margin-top: 10px;">
                        <li><code>[dcp_pay amount="10" currency="ETH"]</code> - Accept Ethereum</li>
                        <li><code>[dcp_pay amount="25" currency="USDC"]</code> - Accept USD Coin</li>
                        <li><code>[dcp_pay amount="50" currency="USDT"]</code> - Accept Tether</li>
                    </ul>
                </div>

                <h4 style="color: #1e40af; margin-top: 20px;">Examples:</h4>
                <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 6px; overflow-x: auto; margin: 10px 0;"><code>[dcp_pay amount="5" label="Donate" currency="ETH"]</code></pre>
                <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 6px; overflow-x: auto; margin: 10px 0;"><code>[dcp_pay amount="99" label="Buy Premium" currency="USDC" success_url="https://yoursite.com/thank-you"]</code></pre>
            </div>

            <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; margin: 20px 0;">
                <h3 style="color: #92400e; margin-top: 0;">🎯 NEW: Custom Success & Error Pages</h3>
                <p style="color: #92400e;">Redirect users to custom pages after payment completion or failure:</p>

                <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 6px; overflow-x: auto; margin: 15px 0;"><code>[dcp_pay amount="10" success_url="https://yoursite.com/thank-you" error_url="https://yoursite.com/error"]</code></pre>

                <h4 style="color: #92400e; margin-top: 20px;">Payment Data Included:</h4>
                <p style="color: #92400e;">The success page receives these URL parameters:</p>
                <ul style="color: #92400e; line-height: 1.8;">
                    <li><code style="background: #fef3c7; padding: 2px 8px; border-radius: 4px;">tx_hash</code> - Blockchain transaction hash</li>
                    <li><code style="background: #fef3c7; padding: 2px 8px; border-radius: 4px;">payment_id</code> - Payment ID in system</li>
                    <li><code style="background: #fef3c7; padding: 2px 8px; border-radius: 4px;">amount</code> - Payment amount</li>
                    <li><code style="background: #fef3c7; padding: 2px 8px; border-radius: 4px;">currency</code> - Token used (ETH, USDC, etc.)</li>
                    <li><code style="background: #fef3c7; padding: 2px 8px; border-radius: 4px;">status</code> - "success" or "error"</li>
                </ul>

                <p style="color: #92400e; margin-top: 15px;"><strong>Example success URL:</strong></p>
                <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 6px; overflow-x: auto; margin: 10px 0; font-size: 12px;"><code>https://yoursite.com/thank-you?tx_hash=0x7f72...&payment_id=01KG...&amount=10&currency=ETH&status=success</code></pre>

                <div style="background: #fff7ed; border: 1px solid #fb923c; padding: 15px; margin: 15px 0; border-radius: 4px;">
                    <strong style="color: #9a3412;">💡 Pro Tip:</strong>
                    <span style="color: #9a3412;"> On your success page, use JavaScript to read these parameters:</span>
                    <pre style="background: #1e293b; color: #e2e8f0; padding: 10px; border-radius: 4px; overflow-x: auto; margin: 10px 0; font-size: 12px;"><code>const params = new URLSearchParams(window.location.search);
const txHash = params.get('tx_hash');
const paymentId = params.get('payment_id');
// Display to user or send to your backend</code></pre>
                </div>
            </div>

            <div style="background: #f0fdf4; border-left: 4px solid #10b981; padding: 20px; margin: 20px 0;">
                <h3 style="color: #065f46; margin-top: 0;">Method 2: Gutenberg Block (Visual Editor)</h3>
                <p style="color: #065f46;">In the page/post editor:</p>
                <ol style="color: #065f46; line-height: 1.8;">
                    <li>Click the <strong>+</strong> button to add a block</li>
                    <li>Search for <strong>"DirectCryptoPay Payment Button"</strong></li>
                    <li>Configure amount, label, and currency in block settings</li>
                    <li>Publish your page</li>
                </ol>
            </div>

            <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; margin: 20px 0;">
                <h3 style="color: #92400e; margin-top: 0;">🛒 Method 3: WooCommerce Gateway (E-commerce)</h3>
                <p style="color: #92400e;"><strong>Automatically accept crypto payments on your WooCommerce store!</strong></p>
                <ol style="color: #92400e; line-height: 1.8;">
                    <li>Make sure <strong>WooCommerce</strong> is installed and active</li>
                    <li>Go to <strong>WooCommerce → Settings → Payments</strong></li>
                    <li>Enable <strong>"DirectCryptoPay"</strong> payment gateway</li>
                    <li>Click <strong>"Manage"</strong> to configure the gateway:
                        <ul style="margin-top: 8px;">
                            <li><strong>Title:</strong> "Pay with Crypto" (or your preferred text)</li>
                            <li><strong>Description:</strong> Message shown at checkout</li>
                            <li><strong>Default Currency:</strong> ETH, USDC, or USDT</li>
                        </ul>
                    </li>
                    <li>Your Integration ID from DirectCryptoPay Settings is used automatically</li>
                    <li>Test with a checkout - the widget launches automatically!</li>
                </ol>
                <div style="background: #fff7ed; border: 1px solid #fb923c; padding: 12px; margin-top: 15px; border-radius: 4px;">
                    <strong style="color: #9a3412;">💡 Payment Flow:</strong>
                    <p style="color: #9a3412; margin: 8px 0 0 0; font-size: 13px;">
                        Customer selects "Pay with Crypto" → Order created → Widget launches → Customer pays → Order marked as "Processing" → Success page
                    </p>
                </div>
            </div>
        </div>

        <!-- Help Section -->
        <div style="background: #fefce8; border: 2px solid #facc15; border-radius: 8px; padding: 20px; margin-top: 30px;">
            <h3 style="color: #854d0e; margin-top: 0;">❓ Need Help?</h3>
            <p style="color: #a16207; margin-bottom: 15px;">Check the complete documentation or contact support:</p>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="https://docs.directcryptopay.com" target="_blank" style="display: inline-block; background: white; color: #854d0e; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 500; border: 2px solid #facc15;">
                    📚 Documentation
                </a>
                <a href="https://directcryptopay.com/dashboard" target="_blank" style="display: inline-block; background: white; color: #854d0e; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 500; border: 2px solid #facc15;">
                    🎛️ Dashboard
                </a>
                <a href="mailto:support@directcryptopay.com" style="display: inline-block; background: white; color: #854d0e; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 500; border: 2px solid #facc15;">
                    ✉️ Support Email
                </a>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Admin notice — the webhook secret is REQUIRED since 1.5.1.
 *
 * Before 1.5.1 the browser could mark an order as paid. That path has been
 * removed: only the HMAC-signed webhook may complete an order. A store with no
 * webhook secret would therefore leave orders stuck in "on-hold", so warn loudly.
 */
add_action('admin_notices', 'dcp_webhook_secret_notice');

function dcp_webhook_secret_notice() {
    if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
        return;
    }
    if (!empty(get_option('dcp_webhook_secret', ''))) {
        return;
    }
    if (!dcp_is_woocommerce_active()) {
        return;
    }
    $gateways = get_option('woocommerce_directcryptopay_settings', array());
    if (!is_array($gateways) || ($gateways['enabled'] ?? 'no') !== 'yes') {
        return;
    }
    printf(
        '<div class="notice notice-error"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
        esc_html__('DirectCryptoPay — action required:', 'directcryptopay'),
        esc_html__('no Webhook Secret is configured. Since version 1.5.1 payments are confirmed exclusively by the signed webhook, so orders will remain On hold until you set it.', 'directcryptopay'),
        esc_url(admin_url('admin.php?page=dcp-settings')),
        esc_html__('Configure it now →', 'directcryptopay')
    );
}

/**
 * Enqueue Widget Script
 */
add_action('wp_enqueue_scripts', 'dcp_load_scripts');

function dcp_load_scripts() {
    // Load the DirectCryptoPay Widget SDK
    // Environment detection with auto-detection fallback:
    // 1. Check DCP_ENV constant (can be set in wp-config.php)
    // 2. Auto-detect based on site URL
    // 3. Default to production

    if (defined('DCP_ENV')) {
        $env = DCP_ENV;
    } else {
        // Auto-detect environment based on site URL
        $site_url = get_site_url();
        if (strpos($site_url, 'localhost') !== false || strpos($site_url, '127.0.0.1') !== false) {
            $env = 'local';
        // SECURITY/CORRECTNESS — match only a leading host label, never a
        // substring anywhere in the URL (e.g. "bestdeveloper.com" must stay production).
        } elseif (preg_match('#^https?://(test|staging|dev)\.#i', $site_url)) {
            $env = 'test';
        } else {
            $env = 'production';
        }
    }

    switch ($env) {
        case 'local':
            $widget_url = 'http://localhost:4001/widget/dcp-widget.umd.js';
            $api_url = 'http://localhost:4001';
            break;
        case 'staging':
        case 'test':
            $widget_url = 'https://preview-api.directcryptopay.com/widget/dcp-widget.umd.js';
            $api_url = 'https://preview-api.directcryptopay.com';
            break;
        case 'production':
        default:
            $widget_url = 'https://api.directcryptopay.com/widget/dcp-widget.umd.js';
            $api_url = 'https://api.directcryptopay.com';
            break;
    }

    wp_enqueue_script(
        'dcp-widget',
        $widget_url,
        [],
        DCP_VERSION,
        true
    );

    // Initialize widget globally after it loads
    wp_add_inline_script(
        'dcp-widget',
        "(function() {
            function initDCP() {
                if (typeof DCP !== 'undefined') {
                    DCP.init({ baseURL: '" . esc_js($api_url) . "' });
                } else {
                    setTimeout(initDCP, 100);
                }
            }
            initDCP();
        })();",
        'after'
    );
}

/**
 * Payment Button Shortcode
 */
add_shortcode('dcp_pay', 'dcp_pay_shortcode');

function dcp_pay_shortcode($atts) {
    $public_id = get_option('dcp_public_id', '');

    // Detect environment for API URL
    if (defined('DCP_ENV')) {
        $shortcode_env = DCP_ENV;
    } else {
        $site_url = get_site_url();
        if (strpos($site_url, 'localhost') !== false || strpos($site_url, '127.0.0.1') !== false) {
            $shortcode_env = 'local';
        // SECURITY/CORRECTNESS — match only a leading host label, never a
        // substring anywhere in the URL (e.g. "bestdeveloper.com" must stay production).
        } elseif (preg_match('#^https?://(test|staging|dev)\.#i', $site_url)) {
            $shortcode_env = 'test';
        } else {
            $shortcode_env = 'production';
        }
    }
    $shortcode_api_url = ($shortcode_env === 'production') ? 'https://api.directcryptopay.com' : (($shortcode_env === 'local') ? 'http://localhost:4001' : 'https://preview-api.directcryptopay.com');

    if (empty($public_id)) {
        return '<div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 15px 0; border-radius: 4px;">
            <strong style="color: #92400e;">⚠️ DirectCryptoPay:</strong>
            <span style="color: #92400e;"> Please configure your Integration ID in </span>
            <a href="' . admin_url('admin.php?page=dcp-settings') . '" style="color: #3b82f6; text-decoration: none; font-weight: 600;">Settings</a>.
        </div>';
    }

    $a = shortcode_atts([
        'amount' => '10',
        'label' => 'Pay with Crypto',
        'currency' => 'ETH',  // Default to ETH (can be overridden: currency="USDC" or currency="USDT")
        'success_url' => '',  // Optional: URL to redirect on success
        'error_url' => '',    // Optional: URL to redirect on error
    ], $atts);

    // Generate unique ID for this button instance
    $button_id = 'dcp-btn-' . uniqid();

    $amount = floatval($a['amount']);
    $currency = strtoupper(sanitize_text_field($a['currency']));  // Normalize to uppercase
    $label = sanitize_text_field($a['label']);
    $success_url = esc_url($a['success_url']);
    $error_url = esc_url($a['error_url']);

    ob_start();
    ?>
    <button id="<?php echo esc_attr($button_id); ?>" class="dcp-payment-button" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 28px; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
        <?php echo esc_html($label); ?>
    </button>
    <script>
    (function() {
        function ensureDCPInit() {
            if (typeof DCP !== 'undefined') {
                DCP.init({ baseURL: '<?php echo esc_js($shortcode_api_url); ?>' });
                return true;
            }
            return false;
        }
        ensureDCPInit();

        var button = document.getElementById('<?php echo esc_js($button_id); ?>');

        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 6px 12px rgba(0,0,0,0.15)';
        });
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
        });

        button.addEventListener('click', async function() {
            if (typeof DCP === 'undefined') {
                alert('DirectCryptoPay widget not loaded. Please refresh the page.');
                return;
            }

            try {
                DCP.init({ baseURL: '<?php echo esc_js($shortcode_api_url); ?>' });

                await DCP.Payment({
                    integrationId: '<?php echo esc_js($public_id); ?>',
                    amount_usd: '<?php echo $amount; ?>',
                    onStatus: function(status) {
                        if (status.type === 'confirmed' || status.type === 'submitted') {
                            var successUrl = '<?php echo esc_js($success_url); ?>';
                            if (successUrl) {
                                var params = new URLSearchParams({
                                    tx_hash: status.txHash || '',
                                    intent_id: status.paymentId || '',
                                    amount: '<?php echo $amount; ?>',
                                    currency: '<?php echo esc_js($currency); ?>',
                                    status: 'success'
                                });
                                window.location.href = successUrl + '?' + params.toString();
                            } else {
                                alert('Payment completed successfully!\n\nTransaction: ' + (status.txHash || 'N/A'));
                            }
                        }
                    }
                });
            } catch (error) {
                if (error.message && error.message.includes('User rejected')) return;

                var errorUrl = '<?php echo esc_js($error_url); ?>';
                if (errorUrl) {
                    var params = new URLSearchParams({
                        error: error.message || 'Unknown error',
                        amount: '<?php echo $amount; ?>',
                        currency: '<?php echo esc_js($currency); ?>',
                        status: 'error'
                    });
                    window.location.href = errorUrl + '?' + params.toString();
                } else {
                    alert('Payment failed: ' + error.message);
                }
            }
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}

/**
 * Gutenberg Block Registration
 */
add_action('init', 'dcp_register_block');

function dcp_register_block() {
    if (!function_exists('register_block_type')) {
        return; // Gutenberg not available
    }

    wp_register_script(
        'dcp-block-editor',
        DCP_PLUGIN_URL . 'assets/block.js',
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
        DCP_VERSION
    );

    register_block_type('directcryptopay/payment-button', [
        'editor_script' => 'dcp-block-editor',
        'render_callback' => 'dcp_render_block',
        'attributes' => [
            'amount' => [
                'type' => 'string',
                'default' => '10',
            ],
            'label' => [
                'type' => 'string',
                'default' => 'Pay with Crypto',
            ],
            'currency' => [
                'type' => 'string',
                'default' => 'USD',
            ],
        ],
    ]);
}

function dcp_render_block($attributes) {
    $shortcode_atts = '';
    foreach ($attributes as $key => $value) {
        if (!empty($value)) {
            $shortcode_atts .= ' ' . $key . '="' . esc_attr($value) . '"';
        }
    }
    return do_shortcode('[dcp_pay' . $shortcode_atts . ']');
}

/**
 * ========================================
 * WooCommerce Integration
 * ========================================
 */

/**
 * Check if WooCommerce is active
 * More robust detection that works with multisite and MU plugins
 */
function dcp_is_woocommerce_active() {
    // Method 1: Check if WooCommerce class exists (most reliable)
    if (class_exists('WooCommerce')) {
        return true;
    }

    // Method 2: Check active plugins
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins', array())))) {
        return true;
    }

    // Method 3: Check network activated plugins (multisite)
    if (is_multisite()) {
        $plugins = get_site_option('active_sitewide_plugins');
        if (isset($plugins['woocommerce/woocommerce.php'])) {
            return true;
        }
    }

    return false;
}

/**
 * Load WooCommerce Gateway if WooCommerce is active
 */
add_action('plugins_loaded', 'dcp_init_woocommerce_gateway', 11);

function dcp_init_woocommerce_gateway() {
    if (!dcp_is_woocommerce_active()) {
        return;
    }

    // Ensure WooCommerce is fully loaded
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    // Include the Gateway class
    $gateway_file = DCP_PLUGIN_DIR . 'includes/class-wc-gateway-directcryptopay.php';
    if (file_exists($gateway_file)) {
        require_once $gateway_file;

        // Register the Gateway
        add_filter('woocommerce_payment_gateways', 'dcp_add_gateway_class');
    } else {
        error_log('DirectCryptoPay: WooCommerce gateway file not found at ' . $gateway_file);
    }
}

/**
 * Add DirectCryptoPay Gateway to WooCommerce
 */
function dcp_add_gateway_class($gateways) {
    $gateways[] = 'WC_Gateway_DirectCryptoPay';
    return $gateways;
}

/**
 * AJAX Handler: Mark order as paid
 *
 * Called from JavaScript after payment confirmation
 */
add_action('wp_ajax_dcp_mark_order_paid', 'dcp_mark_order_paid');
add_action('wp_ajax_nopriv_dcp_mark_order_paid', 'dcp_mark_order_paid');

function dcp_mark_order_paid() {
    if (!isset($_POST['order_id']) || !isset($_POST['order_key']) || !isset($_POST['tx_hash'])) {
        wp_send_json_error(array('message' => 'Missing required parameters'));
        return;
    }

    $order_id  = intval($_POST['order_id']);
    $order_key = sanitize_text_field($_POST['order_key']);
    $tx_hash   = sanitize_text_field($_POST['tx_hash']);
    $intent_id = isset($_POST['intent_id']) ? sanitize_text_field($_POST['intent_id']) : '';
    $chain_id  = isset($_POST['chain_id']) ? intval($_POST['chain_id']) : 0;
    $currency  = isset($_POST['currency']) ? sanitize_text_field($_POST['currency']) : '';

    // Verify nonce
    if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'dcp_mark_order_paid_' . $order_id)) {
        wp_send_json_error(array('message' => 'Invalid nonce'));
        return;
    }

    $order = wc_get_order($order_id);

    if (!$order) {
        wp_send_json_error(array('message' => 'Order not found'));
        return;
    }

    if ($order->get_order_key() !== $order_key) {
        wp_send_json_error(array('message' => 'Invalid order key'));
        return;
    }

    if ($order->has_status(array('processing', 'completed'))) {
        wp_send_json_success(array('message' => 'Order already completed'));
        return;
    }

    /*
     * SECURITY — the client is NEVER authoritative for payment state.
     *
     * This endpoint is reachable unauthenticated (guest checkout), and both the
     * order key and the nonce are legitimately held by the buyer for their own
     * order. Neither is an authorisation to mark an order as paid.
     *
     * The order is therefore only moved to "on-hold" as a UX acknowledgement.
     * Only the HMAC-signed webhook from the DCP backend — which verifies the
     * transaction on-chain — may call payment_complete().
     */
    if ($order->has_status('pending')) {
        $order->update_status(
            'on-hold',
            sprintf(
                __('DirectCryptoPay: transaction reported by the buyer, awaiting on-chain confirmation.%sTX: %s%s', 'directcryptopay'),
                PHP_EOL, $tx_hash,
                $intent_id ? PHP_EOL . 'Intent: ' . $intent_id : ''
            )
        );
    }

    $order->update_meta_data('_dcp_reported_tx_hash', $tx_hash);
    if ($intent_id) {
        $order->update_meta_data('_dcp_intent_id', $intent_id);
    }
    if ($chain_id) {
        $order->update_meta_data('_dcp_chain_id', $chain_id);
    }
    if ($currency) {
        $order->update_meta_data('_dcp_currency', $currency);
    }
    $order->update_meta_data('_dcp_payment_method', 'crypto');
    $order->save();

    wp_send_json_success(array(
        'message'  => 'Transaction recorded, awaiting on-chain confirmation',
        'order_id' => $order_id,
        'status'   => $order->get_status()
    ));
}

/**
 * ========================================
 * WooCommerce Order Meta Box — DCP Details
 * ========================================
 */
add_action('add_meta_boxes', 'dcp_add_order_meta_box');

function dcp_add_order_meta_box() {
    $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController')
        && wc_get_container()->get(\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class)->custom_orders_table_usage_is_enabled()
        ? wc_get_page_screen_id('shop-order')
        : 'shop_order';

    add_meta_box(
        'dcp-payment-details',
        '💎 DirectCryptoPay Payment',
        'dcp_render_order_meta_box',
        $screen,
        'side',
        'high'
    );
}

function dcp_render_order_meta_box($post_or_order) {
    $order = ($post_or_order instanceof WC_Order) ? $post_or_order : wc_get_order($post_or_order->ID);
    if (!$order) return;

    // Only show for DCP orders
    if ($order->get_payment_method() !== 'directcryptopay') {
        echo '<p style="color: #999; font-style: italic;">Not a DirectCryptoPay payment.</p>';
        return;
    }

    $tx_hash   = $order->get_meta('_dcp_tx_hash');
    $intent_id = $order->get_meta('_dcp_intent_id');
    $chain_id  = $order->get_meta('_dcp_chain_id');
    $currency  = $order->get_meta('_dcp_currency');

    // Chain name mapping
    $chains = array(
        1     => 'Ethereum',
        137   => 'Polygon',
        56    => 'BNB Chain',
        42161 => 'Arbitrum',
        10    => 'Optimism',
        8453  => 'Base',
        11155111 => 'Sepolia (Testnet)',
        80002 => 'Amoy (Testnet)',
        97    => 'BSC Testnet',
    );

    // Explorer URL mapping
    $explorers = array(
        1     => 'https://etherscan.io/tx/',
        137   => 'https://polygonscan.com/tx/',
        56    => 'https://bscscan.com/tx/',
        42161 => 'https://arbiscan.io/tx/',
        10    => 'https://optimistic.etherscan.io/tx/',
        8453  => 'https://basescan.org/tx/',
        11155111 => 'https://sepolia.etherscan.io/tx/',
        80002 => 'https://amoy.polygonscan.com/tx/',
        97    => 'https://testnet.bscscan.com/tx/',
    );

    $chain_name = isset($chains[(int)$chain_id]) ? $chains[(int)$chain_id] : '';
    $explorer_url = isset($explorers[(int)$chain_id]) ? $explorers[(int)$chain_id] : '';

    echo '<table style="width:100%; font-size:13px; border-collapse:collapse;">';

    if ($tx_hash) {
        $short_hash = substr($tx_hash, 0, 10) . '...' . substr($tx_hash, -6);
        $link = ($explorer_url && $tx_hash) ? '<a href="' . esc_url($explorer_url . $tx_hash) . '" target="_blank" style="color:#3b82f6; text-decoration:none;">' . esc_html($short_hash) . ' ↗</a>' : esc_html($short_hash);
        echo '<tr><td style="padding:6px 0; color:#666; vertical-align:top;">TX Hash</td><td style="padding:6px 0; font-family:monospace; word-break:break-all;">' . $link . '</td></tr>';
    }

    if ($chain_name) {
        echo '<tr><td style="padding:6px 0; color:#666;">Network</td><td style="padding:6px 0;">' . esc_html($chain_name) . '</td></tr>';
    }

    if ($currency) {
        echo '<tr><td style="padding:6px 0; color:#666;">Currency</td><td style="padding:6px 0; font-weight:600;">' . esc_html(strtoupper($currency)) . '</td></tr>';
    }

    if ($intent_id) {
        $short_intent = strlen($intent_id) > 20 ? substr($intent_id, 0, 16) . '...' : $intent_id;
        echo '<tr><td style="padding:6px 0; color:#666;">Intent ID</td><td style="padding:6px 0; font-family:monospace; font-size:12px;">' . esc_html($short_intent) . '</td></tr>';
    }

    if (!$tx_hash && !$intent_id) {
        echo '<tr><td colspan="2" style="padding:6px 0; color:#999; font-style:italic;">Payment data will appear after confirmation.</td></tr>';
    }

    echo '</table>';
}
